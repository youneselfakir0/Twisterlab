"""Real agents package."""

from .browser_agent import RealBrowserAgent  # noqa: F401

__all__ = ["RealBrowserAgent"]
