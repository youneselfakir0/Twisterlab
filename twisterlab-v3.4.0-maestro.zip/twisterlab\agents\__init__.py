"""Agents package."""

from . import registry

__all__ = ["core", "real", "support", "mcp", "registry"]
